# msfvenom options

It takes quite a while to get msfvenom to list its various options so I have
redirected the output to text files and made them available here.  The
msfvenom.zip file contains a copy of all of the other files in this
directory.  Tell GitHub to show it to you.  It will say that it can't and
offer you a download button instead.
